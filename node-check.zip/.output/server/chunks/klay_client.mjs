import { defineEventHandler, useQuery } from 'h3';
import { u as useHttp } from './useHttp.mjs';
import 'axios';

const klay_client = defineEventHandler(async (event) => {
  const { httpService } = useHttp();
  const query = useQuery(event);
  const rpcBody = { "jsonrpc": "2.0", "method": "klay_clientVersion", "id": 1 };
  return await httpService(query.baseUrl, rpcBody);
});

export { klay_client as default };
//# sourceMappingURL=klay_client.mjs.map
