import { defineEventHandler, useQuery } from 'h3';
import { u as useHttp } from './useHttp.mjs';
import 'axios';

const txpool_status = defineEventHandler(async (event) => {
  const { httpService } = useHttp();
  const query = useQuery(event);
  const rpcBody = { "jsonrpc": "2.0", "method": "txpool_status", "id": 1 };
  return await httpService(query.baseUrl, rpcBody);
});

export { txpool_status as default };
//# sourceMappingURL=txpool_status.mjs.map
