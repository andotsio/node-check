const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "file": "entry-297d8e39.mjs",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "pages/index.vue"
    ],
    "css": [
      "entry.4150d033.css"
    ],
    "assets": [
      "nodeHost.61cd198e.svg",
      "chainId.c700b5f5.svg",
      "latestHeight.f1e51a72.svg",
      "protocol.f8986dd1.svg",
      "connectStatus.379ea6c3.svg",
      "client.d62c944d.svg",
      "nodeHeight.33faedc8.svg",
      "icon_error.dd0a35d4.svg",
      "icon_success.8818962b.svg",
      "icon_backTop.6da7df9d.svg"
    ]
  },
  "pages/index.vue": {
    "file": "index-80775fbf.mjs",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
