const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "file": "entry-d95393cb.mjs",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "pages/index.vue"
    ],
    "css": [
      "entry.23ab440d.css"
    ],
    "assets": [
      "icon_error.dd0a35d4.svg",
      "icon_success.8818962b.svg",
      "icon_backTop.6da7df9d.svg"
    ]
  },
  "pages/index.vue": {
    "file": "index-f58d3dea.mjs",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
