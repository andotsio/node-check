import { defineEventHandler } from 'h3';
import { u as useHttp } from './useHttp.mjs';
import 'axios';

const klay_main_blockNumber = defineEventHandler(async (event) => {
  const { httpService } = useHttp();
  const rpcBody = { "jsonrpc": "2.0", "method": "klay_blockNumber", "params": [], "id": 83 };
  const data = await httpService("", rpcBody);
  console.log("main", data);
  return data;
});

export { klay_main_blockNumber as default };
//# sourceMappingURL=klay_main_blockNumber.mjs.map
