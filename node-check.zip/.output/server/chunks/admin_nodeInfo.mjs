import { defineEventHandler, useQuery } from 'h3';
import { u as useHttp } from './useHttp.mjs';
import 'axios';

const admin_nodeInfo = defineEventHandler(async (event) => {
  const { httpService } = useHttp();
  const query = useQuery(event);
  const rpcBody = { "jsonrpc": "2.0", "method": "admin_nodeInfo", "id": 1 };
  return await httpService(query.baseUrl, rpcBody);
});

export { admin_nodeInfo as default };
//# sourceMappingURL=admin_nodeInfo.mjs.map
