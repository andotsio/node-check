import { defineEventHandler, useQuery } from 'h3';
import { u as useHttp } from './useHttp.mjs';
import 'axios';

const klay_syncing = defineEventHandler(async (event) => {
  const { httpService } = useHttp();
  const query = useQuery(event);
  const rpcBody = { "jsonrpc": "2.0", "method": "klay_syncing", "params": [], "id": 1 };
  return await httpService(query.baseUrl, rpcBody);
});

export { klay_syncing as default };
//# sourceMappingURL=klay_syncing.mjs.map
