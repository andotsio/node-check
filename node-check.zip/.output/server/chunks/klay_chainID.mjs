import { defineEventHandler, useQuery } from 'h3';
import { u as useHttp } from './useHttp.mjs';
import 'axios';

const klay_chainID = defineEventHandler(async (event) => {
  const { httpService } = useHttp();
  const query = useQuery(event);
  const rpcBody = { "jsonrpc": "2.0", "method": "klay_chainID", "id": 1 };
  return await httpService(query.baseUrl, rpcBody);
});

export { klay_chainID as default };
//# sourceMappingURL=klay_chainID.mjs.map
