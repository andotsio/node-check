import { defineEventHandler, useQuery } from 'h3';
import { u as useHttp } from './useHttp.mjs';
import 'axios';

const klay_peer = defineEventHandler(async (event) => {
  const { httpService } = useHttp();
  const query = useQuery(event);
  const rpcBody = { "jsonrpc": "2.0", "method": "net_peerCount", "params": [], "id": 74 };
  return await httpService(query.baseUrl, rpcBody);
});

export { klay_peer as default };
//# sourceMappingURL=klay_peer.mjs.map
