import { defineEventHandler, useQuery } from 'h3';
import { u as useHttp } from './useHttp.mjs';
import 'axios';

const klay_accounts = defineEventHandler(async (event) => {
  const { httpService } = useHttp();
  const query = useQuery(event);
  const rpcBody = { "jsonrpc": "2.0", "method": "klay_accounts", "params": [], "id": 1 };
  return await httpService(query.baseUrl, rpcBody);
});

export { klay_accounts as default };
//# sourceMappingURL=klay_accounts.mjs.map
