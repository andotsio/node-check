import axios from 'axios';

const useHttp = () => {
  const httpService = async (baseURL = "https://public-node-api.klaytnapi.com/v1/cypress", rpcBody) => {
    if (rpcBody.method === "txpool_status") {
      console.log(baseURL);
    }
    try {
      let httpService2 = axios.create({
        baseURL,
        headers: {
          "Content-Type": "application/json"
        }
      });
      httpService2.interceptors.request.use(function(request) {
        request.requestStart = Date.now();
        return request;
      });
      httpService2.interceptors.response.use(function(response) {
        response.latency = Date.now() - response.config.requestStart;
        return response;
      }, function(error) {
        if (error.response) {
          error.response.latency = null;
        }
        return Promise.reject(error);
      });
      const { data, latency } = await httpService2.post("", rpcBody);
      console.log(data);
      return { ...data, latency };
    } catch (error) {
      console.log(baseURL, error);
      return null;
    }
  };
  return {
    httpService
  };
};

export { useHttp as u };
//# sourceMappingURL=useHttp.mjs.map
