import axios from 'axios';

const useHttp = () => {
  const httpService = async (baseURL, rpcBody) => {
    try {
      let API = axios.create({
        baseURL,
        headers: {
          "Content-Type": "application/json"
        }
      });
      API.interceptors.request.use(function(request) {
        request.requestStart = Date.now();
        return request;
      });
      API.interceptors.response.use(function(response) {
        response.latency = Date.now() - response.config.requestStart;
        return response;
      }, function(error) {
        if (error.response) {
          error.response.latency = null;
        }
        return Promise.reject(error);
      });
      const { data, latency } = await API.post("", rpcBody);
      console.log("httpService", baseURL, data, latency);
      return { ...data, latency };
    } catch (error) {
      return null;
    }
  };
  return {
    httpService
  };
};

export { useHttp as u };
//# sourceMappingURL=useHttp.mjs.map
